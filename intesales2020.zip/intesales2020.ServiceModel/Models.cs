﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ServiceStack;
using ServiceStack.DataAnnotations;

namespace intesales2020.ServiceModel
{
    [Route("/hello/{Name}")]
    public class Models : IReturn<HelloResponse>
    {
        public string Name { get; set; }
    }

    public class HelloResponse
    {
        public string Result { get; set; }
    }
    public class CrudPerson
    {
        [AutoIncrement] public int Id { get; set; }

        public string Name { get; set; }
    }
    public class PersonResponse
    {
        public int Id { get; set; }
        public ResponseStatus ResponseStatus { get; set; }
    }
}