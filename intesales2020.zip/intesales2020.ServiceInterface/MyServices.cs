﻿using ServiceStack;
using intesales2020.ServiceModel;

namespace intesales2020.ServiceInterface
{
    public class MyServices : Service
    {
        public object Any(Models request)
        {
            return new HelloResponse { Result = $"Hello, {request.Name}!" };
        }
    }
    public class CreateCrudPerson : ICreateDb<CrudPerson>, IReturn<PersonResponse>
    {
        public string Name { get; set; }
    }
    public class FindCrudPerson : QueryDb<CrudPerson> { }
}