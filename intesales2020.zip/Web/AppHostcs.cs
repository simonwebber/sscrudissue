﻿using System.Configuration;
using System.Web.Mvc;
using Funq;
using ServiceStack;
using intesales2020.ServiceInterface;
using ServiceStack.Admin;
using ServiceStack.Data;
using ServiceStack.Mvc;
using ServiceStack.OrmLite;

namespace intesales2020.Web
{
    public class AppHost : AppHostBase
    {
        /// <summary>
        /// Base constructor requires a Name and Assembly where web service implementation is located
        /// </summary>
        public AppHost()
            : base("intesales2020", typeof(MyServices).Assembly) { }

        /// <summary>
        /// Application specific configuration
        /// This method should initialize any IoC resources utilized by your web service classes.
        /// </summary>
        public override void Configure(Container container)
        {
            var connectionString =
                string.Format(ConfigurationManager.AppSettings["DatabaseConnectionString"]);

            container.Register<IDbConnectionFactory>(c =>
                new OrmLiteConnectionFactory(
                    connectionString,
                    SqlServer2012Dialect.Provider));
            Plugins.Add(new AdminFeature());
            Plugins.Add(new AutoQueryFeature { MaxLimit = 100 });
            container.AddSingleton<ICrudEvents>(c =>
                new OrmLiteCrudEvents(c.Resolve<IDbConnectionFactory>())
                {
                    // NamedConnections = { used for multi-tenant support }
                });
            container.Resolve<ICrudEvents>().InitSchema();
            SetConfig(new HostConfig
            {
                HandlerFactoryPath = "api",
            });
            //Set MVC to use the same Funq IOC as ServiceStack
            ControllerBuilder.Current.SetControllerFactory(
                new FunqControllerFactory(container));
        }
    }
}