﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using intesales2020.ServiceInterface;
using ServiceStack;
using ServiceStack.Mvc;

namespace Web.Controllers
{
    public class HomeController : ServiceStackController
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            var gateway = HostContext.AppHost.GetServiceGateway(base.HttpContext.ToRequest());
            var result = gateway.Send(new CreateCrudPerson { Name = "FromContact" });
            //var drId = HostContext.ServiceController.Execute
            //(new CreateCrudPerson
            //{
            //    Name = "FromContact"
            //});

            return View();
        }
    }
}