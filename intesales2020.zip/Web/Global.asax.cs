﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using intesales2020.ServiceInterface;
using intesales2020.Web;
using ServiceStack;

namespace Web
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            new AppHost().Init();
            var drId = HostContext.ServiceController.Execute
            (new CreateCrudPerson
            {
                Name = "New One Works"
            });

        }
    }
}
